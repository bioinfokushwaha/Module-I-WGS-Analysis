##########  3. Matrix  ########
# Matrix is a combination of two or more vectors with the same data type in different dimension
# Two-dimensional array.
# Exaple: Students Marks (names in row and subjects in columns)

#     C1 C2 C3 C4 C5   ---> Subjects
# R1  15  14  15  17  19
# R2  12  13  16  18 20


## A. Syntax: Matrix creation 
      # matrix(data = NA, nrow = 1, ncol = 1, byrow = FALSE, dimnames = NULL)

      #Arguments: 
      #data: number of elements which will arrange into the rows and columns of the matrix \
      #nrow: Number of rows 
      #ncol: Number of columns 
      #byrow: The rows are filled from the left to the right.byrow = FALSE (default values)
      #dinnames: name of dimension. NULL/a list of length 2/ 
      #dimnames = list(c("row1", "row2"......), c("C.1", "C.2", "C.3" ......)))

     
      Mat<-matrix(1:10,ncol=5) ; Mat
      Mat<-matrix(1:10, nrow=2, byrow = TRUE) ; Mat
      Mat<-matrix(1:10,nrow=2, dimnames=list(c("R1","R2"),c("C1","C2","C3","C4","C5"))); Mat
    
      
      # Rules for vector naming: Same as variable
  
## B. Access of variable value
      Mat
      dim(Mat)  #Note: dim function to know the size of matrix
  
        #     C1 C2 C3 C4 C5 
        # R1  1  3  5  7  9
        # R2  2  4  6  8  10
  
      # slicing/subsetting of vector. 
  
      # [row, col]: select one or many elements from a matrix by using the square brackets 
      # (:) represent range 
      
      # For single element: exact coordinates 
          # Mat[1,2] selects the element at the first row and second column.
          Mat[1,2]
      # For multiple elements: Range
      # Mat [1:2,2:5] 
        Mat [1:2,2:5] 
        
      # Whole columns 
      # Mat [,1] selects all elements of the first column.
        Mat [,1] 
        
      # Whole rows
      # Mat [1,] selects all elements of the first row  
        Mat [1,] 


## D.  Deletion of variable
      rm(Mat); Mat
    

## E. Usefull function  related to Matrix
      
      # add a column to a matrix with the cbind() command. cbind() means column binding.
      
      #     C1 C2 C3 C4 C5 
      # R1  15  14  15  17  19
      # R2  12  13  16  18 20
      
        Mat; dim(Mat)
        Mat_c <- cbind(Mat,c(1:2)) ## To add column C6
        Mat_c
    
      # add a row to a matrix with the rbind() command. rbind() means row binding.
        Mat_r <- rbind(Mat_c, c(1:6))  ## To add column Row-3
        Mat_r

      # colSums(Mat): Returns vector of column sums. 
        colSums(Mat_r)
    
      #rowSums(Mat) 	Returns vector of row sums. 
        rowSums(Mat_r)
    
      #colMeans(Mat): Returns vector of column means.
        colMeans(Mat_r)
    
      #rowMeans(Mat) 	Returns vector of row means.
        rowMeans(Mat_r)
    
      # is.matrix(Mat)
        is.matrix(Mat_r)
        
      #t(Mat_r) Transpose
        Mat_r
        t(Mat_r) 
    
  

## F. Basic operation 
    A <- matrix(c(2,3,-2,1,2,2),3,2); A
    B <- matrix(c(1,4,-2,1,2,1),3,2); B
    
    # Addition/ substraction / Multipleication (element to element)
    C <- A + B; C
    D <- A - B; D
    E <- A * B; E
    F <- A^B; F
    
    # Identity Matrix : to create a matrix of with given diagonal elements
    I <- diag(c(1,1,1)); I
    I1 <- diag(c(1,1,1,1)); I1
    
    # Unit Matrix (1, number of rows, number of columns)
    U <- matrix(1,3,5); U
    
    # Zero Matrix (0, number of rows, number of columns)
    Z <- matrix(0,3,2); Z
    
    # empty matix
    Y<-matrix(,2,4); Y
  
    ## Logical operations
    A>B; B<A
    A<3 | B<5

