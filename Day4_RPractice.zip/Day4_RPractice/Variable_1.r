##########  1. Variable  ########
# Variables can store a number, vector, dataset or any outputs of R program. 

## A. Variable Creation 
      # Variable naming (letter, digit . and _) 
      # To declare a variable:  use the `<-` (leftward, rightward) OR  `=` (equal)
      
      # 1.  name_of_variable <- value
      # 2.  value -> name_of_variable
      # 3.   name_of_variable = value
        
        
         rm(list=ls())  ## Remove all the variable from workspace
 
## B. Access of variable value: print() or cat() 
      # cat() can print multiple items together.
      name_of_variable

      x <- 3
      x
      3->x1; x1
      y=5; y
      z="R is great"; z
      l <- TRUE;l
      
      print (x);
      cat (x,y)
      
    
    #Note: class function : to know the data type variable
    class(x); class(y); class(z); class(l)


## C. To deletion of variable
      rm(x); 
      x
      rm (b_b,b11); 
      b_b;b11
      
      
## D To find variable
      ls() #OR 
      print(ls())

## E. Basic operation
      # Arithematic operations

        # + 	: Addition
        # - 	: Subtraction
        # * 	: Multiplication
        # / 	: Division
        # ^ or **  : Exponentiation 
        # %% 	: Modulus (Remainder from division)
        # %/% : Integer Division

        x=3    # recreating because we deleted earlier
        x; y
        x+y; 
        x-y; 
        x*y; 
        y/x; 
        y%%x
        y%/%x
        x^2 ; 
        x^y;

      # Logical operation 
        # < 	:less than
        # <= 	:less than or equal to
        # > 	:greater than
        # >= 	:greater than or equal to
        # == 	:exactly equal to
        # != 	:not equal to
        # x | y 	:x OR y
        # x & y 	:x AND y


        x > 8
        y < 3
        x == 3
        x!= 3
        x > 2 | x < 1
        x > 2 & x < 1

        