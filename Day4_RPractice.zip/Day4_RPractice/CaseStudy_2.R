## Plotting with dataset
## Purpose : To understand data and explore hidden pattern
# Requirement: data :(variable, vector, matrix, Df,List)
# Possibility 1: Create dataset 
#             2: Use built-in dataset
#             3: import dataset
rm(list=ls())
#required packages and data;
library(datasets)  # Load/unload base packages manually
data()
?iris
datasets::iris #### To see dataset

## Objective of dataset creation  
#Question : is sepal/petal length/width can be use tp identify plant species?

### Outlook of iris dataset ######
head(iris,3)           # quick look of dataset
class(iris)            # R object class
dim(iris)              # dimension
colnames(iris)         # To know data variable
row.names(iris) 

## comprehensive summary of variable/dataset
summary(iris$Sepal.Length)    ## Numerics/ quantitative
summary(iris$Species)         # Character/label
summary(iris)

##### Data Plotting with PLOT() #############
plot(iris$Species)       # Categorical variable
plot(iris$Petal.Length)  # Quantitative variable

#########  Q1: What is relation between variable #############

# Categorical x Quantitative
plot(iris$Species, iris$Petal.Width,xlab="Species",ylab="Petal width",
     col=c("red","green","blue"))  
plot(iris$Species, iris$Petal.Width,col=c("red","green","blue")) 

## Quantitative x Quantitative : Relation between two variable
plot(iris$Petal.Length, iris$Petal.Width) 
plot(iris)  # Entire data frame

# Plot with options
plot(iris$Petal.Length, iris$Petal.Width,
     col = "#cc0000",  # Hex code for datalab.cc red
     pch = 20,         # Use circles for points:19,20,21,22
     main = "Iris: Petal Length vs. Petal Width",
     xlab = "Petal Length",ylab = "Petal Width")

plot(iris$Petal.Length, iris$Petal.Width,
     col = c(iris$Species),  # Hex code for datalab.cc red
     pch = 20,         # Use circles for points:19,20,21,22
     main = "Iris: Petal Length vs. Petal Width",
     xlab = "Petal Length",ylab = "Petal Width")


## Scatter plot: 
#   1: Visualization of relationship of two quatitative variable
# Association between variables (eg: Linear/random/exp..)
# Spread of data(one>--<other)
# Outliers (treatment)
# Correlation 

## Data distribution: normal distribution
m<-mean(iris$Petal.Length);m
std<-sqrt(var(iris$Petal.Length));std
curve(dnorm(x,mean=m, sd=std), 
      col="darkblue", lwd=2,add=TRUE)

#########  Q2: What is the best parameters to identify species #############
cor(iris$Petal.Length,iris$Petal.Width);
cor(iris$Sepal.Length,iris$Sepal.Width);
plot(iris$Sepal.Length, iris$Sepal.Width)
t.test(iris$Petal.Length,iris$Petal.Width)
t.test(iris$Sepal.Length, iris$Sepal.Width)

#### correlation values for variables of dataset
cor(iris)
head(iris)
df<-iris[,1:4];head(df)
cor(df)
res<-cor(df,method="pearson"); res
round(res, 3)

### correlation and  significance
#install.packages("Hmisc")
library(Hmisc)
res<-rcorr(as.matrix(df),type="spearman");res
summary(res)
round(res$r,3)
round(res$P,6)
class(res)

### Correlation and P-vlaue table
### Functions in R #####
#1  function_name <- function(arg_1, arg_2, ...) 
#                  {
#                      Function body 
#                  }
#2 Calling of function

flattenCorrMatrix <- function(cormat, pmat) {
  ut <- upper.tri(cormat)   ###  
  data.frame(
    row = rownames(cormat)[row(cormat)[ut]],
    column = rownames(cormat)[col(cormat)[ut]],
    cor  =(cormat)[ut],
    p = pmat[ut]
  )
}
Iris_cor_pvalue <- flattenCorrMatrix(res$r, res$P)
ut <- upper.tri(res$r);ut
rownames(res$r)[row(res$r)[ut]]
rownames(res$r)[col(res$r)[ut]]
(res$r)[ut]
res$P[ut]


### Ploting #####
#install.packages("corrplot")
library(corrplot)
corrplot(res$r, type = "upper", order = "hclust", tl.col = "black", tl.srt = 0)
# type=upper/lower/full
# order: correlation reordered through correlation coefficient using "hclust" method.
# text label color: tl.col
# for text label string rotation: tl.srt 

#install.packages("PerformanceAnalytics")
library(PerformanceAnalytics)
chart.Correlation(df, histogram=TRUE, pch=19)

col<- colorRampPalette(c("blue", "white", "red"))(20)
#heatmap(x = res$r, col = col, symm = TRUE)

rm(list=ls())
#########  Q3: What is distribution type of my data #############
# How to find distribution
#install.packages("fitdistrplus")
library(fitdistrplus)
normal_dist <- fitdist(iris$Petal.Length, "norm"); plot(normal_dist)
gamma_dist <- fitdist(iris$Petal.Length, "gamma"); 
plot(gamma_dist)

################## Quantile-Quantile plot ##############
# To find the type/compare of quantile distribution variables
# Graphical "goodness of fit", rather a reducing numerical summary(quantifiable)

################### P-P Plot ##################
# used to visually evaluate the skewness of a distribution. 
gamma_dist <- fitdist(iris$Petal.Length, "gamma"); plot(gamma_dist)

## Density: 
## Represents the distribution of values in a dataset
#  i.e. concentrated area 
#   1. Give good idea of shape (number of peaks)
#       single(unimodal), two(bimodal) and more(multimodal)
#   2. summarized representation of frequencies of large data 
#   3. x-axis (data value) and y-axis (relative frequency)
#       data points (150): density peak is 0.5 = frequency is 75
#   4. Symmetrical/Asymmetry

###### Skewness ###
#   Distortion in data distribution (direction of distortion)
#   Differentiate extremes values of one end to other end
#   5. Skewness (no/Left/right skewed)
#       (+ve skewness): Right side tail is longer (mean & median > mode)
#       (-ve skewness): Left side tail is longer  (mode> mean & median)
#        (0): no skewness: (mean=mode=median)
#       0:-0.5/0-0.5 no skewness 
#       -0.5:-1/0.5-1 moderate
#       <-1/1>: highly skewed
#   6. importance
#        LM:independent variable and response variable
#        high level of unpredictability

##### Kurtosis 
#    Measure outlier in distribution
#    High kurtosis: heavy tails or outliers (matter of investigation)
#    Low kurtosis : tails or lack of outliers (investigate/do trimming of unwanted results
#    K=3 for standard normal distribution 

######## Q4: What are the statistical parameters #######
## vars,count,mean,sd,median,trimmed,mad,min,max,range,
# skew, kurtosis

summary(gamma_dist)
summary(normal_dist)
### Selection of model and fitness
# Loglikelihood: Higher the score better the fit of model 
# Akaike information criterion (AIC): Estimator of prediction error  
# Bayesian Information Criterion (BIC): reverse to Loglikelihood

############ Q5: For you ###
install.packages("psych")
library(psych)
describe(iris$Petal.Length)
describe(iris$Petal.Width)
describe(iris)
data1<-describe(iris)
data1$se
plot(data1$se)
data1$kurtosis
data1$skew

## CLEAN UP #############

# Clear packages
detach("package:datasets", unload = TRUE)
# Clear plots
dev.off()  # But only if there IS a plot
# Clear console
cat("\014")  # ctrl+L

## # BAR CHARTS ######
# Simple and good (direct)
# Quantitative variables
barplot(iris$Petal.Length)             # Doesn't work
# Need a table with frequencies for each category
PL <- table(iris$Petal.Length)  # Create table
barplot(PL)              # Bar chart
plot(PL)                 # Default X-Y plot (lines)

## BASIC HISTOGRAMS ######################
## Similar to Bar Chart (quantitative:scale/ratio/intervel/mesaured)
#     Shape of data
#     Gaps in distributions
#     Outliers
#     Symmetery
hist(iris$Sepal.Length)
hist(iris$Sepal.Width)
hist(iris$Petal.Length)
m<-mean(iris$Petal.Length);m
std<-sqrt(var(iris$Petal.Length));std
curve(dnorm(x,mean=m, sd=std), 
      col="darkblue", lwd=2,add=TRUE)


### Graph fitting #######
## Line fitting 
hist(iris$Petal.Length)
myhist <- hist(iris$Petal.Length);myhist;myhist$counts
multiplier <- myhist$counts / myhist$density; multiplier
mydensity <- density(iris$Petal.Length);mydensity
mydensity$y <- mydensity$y * multiplier[1]; mydensity$y
plot(myhist)
lines(mydensity,col="red",lwd=4)

#### Fitting by GROUP ##########
# Put graphs in 3 rows and 1 column
hist(iris$Petal.Width [iris$Species == "setosa"],xlim = c(0, 3),breaks = 9,
     main = "Petal Width for Setosa",xlab = "", col = "red")
hist(iris$Petal.Width [iris$Species == "versicolor"],xlim = c(0, 3),breaks = 9,
     main = "Petal Width for Versicolor", xlab = "",col = "purple")

par(mfrow = c(3, 1))
# Histograms for each species using options
hist(iris$Petal.Width [iris$Species == "setosa"],xlim = c(0, 3),breaks = 9,
     main = "Petal Width for Setosa",xlab = "", col = "red")

hist(iris$Petal.Width [iris$Species == "versicolor"],xlim = c(0, 3),breaks = 9,
     main = "Petal Width for Versicolor", xlab = "",col = "purple")

hist(iris$Petal.Width [iris$Species == "virginica"],xlim = c(0, 3),breaks = 9,
     main = "Petal Width for Virginica",xlab = "",col = "blue")


# Restore graphic parameter
par(mfrow=c(1, 1))
#?par

### Overlaying Plot 
hist(iris$Petal.Length)
hist(iris$Petal.Length,
     breaks = 14, # "Suggests" 14 bins
     freq   = FALSE,       # Axis shows density, not freq.
     col    = "thistle1",  # Color for histogram
     main   = paste("Petal length"),
     xlab   = "Petal Length")
curve(dnorm(x, mean = mean(iris$Petal.Length), sd = sd(iris$Petal.Length)),
      col = "red",  # Color of curve
      lwd = 2,           # Line width of 2 pixels
      add = TRUE)        # Superimpose on previous graph

# Add two kernel density estimators
lines(density(iris$Petal.Length), col = "blue", lwd = 2)
lines(density(iris$Petal.Length, adjust = 1), col = "green", lwd = 2)
?density
# Add a rug plot
rug(iris$Petal.Length, lwd = 2, col = "gray")


######################## 3. Data Import in R ########################
getwd(); dir()
#setwd("")
### 1. Importing data from XL
#install.packages(readxl)
#library(xlsx)
rm(list=ls())
library(readxl)
#?read_xlsx()
#read_xlsx(path, sheet = NULL, range = NULL, col_names = TRUE,
#     col_types = NULL, na = "", trim_ws = TRUE, skip = 0,
#     n_max = Inf, guess_max = min(1000, n_max),progress = readxl_progress(), .name_repair = "unique")

Sheet1 <- read_xlsx("Annotation.xlsx", sheet = 1, range= NULL, col_names = TRUE)

Sheet2 <- read_xlsx("Annotation.xlsx", sheet = 2, range= NULL, col_names = TRUE)


### 2. Tab delimited file
seqdata <- read.delim(file="Anno_exp.txt",header = TRUE, sep = "\t", stringsAsFactors = FALSE); head(seqdata,3)
## 3. CSV 
seqdata1 <- read.csv(file="Anno.csv.csv",header = TRUE, sep = ",", stringsAsFactors = FALSE); head(seqdata1,3)


##################  All in one  #############
install.packages("rio")
library(rio)
xl<-import("Annotation.xlsx", sheet=4); head(xl)
Tab<-import("Anno_exp.txt"); head(Tab,3)
Csv<-import("Anno.csv.csv"); head(Csv,3)

##### Task-1: Merge data 
#install.packages("dplyr")
library(dplyr)
rm(list=ls())         # To delete all variables of workspace
getwd()               # To know working dir
           
dir()                 # To see files at WD

# For the merging of two datasets, we need common ids
# left_join (join as per left DF )
# right_join (join as per right DF)
# inner_join (join as per common)
# full_join  (join the both dataset as Unioin)

DF<-import("Annotation.xlsx", sheet=5); head(DF)
DF2<-import("Annotation.xlsx", sheet=6); head(DF2)

# Data1           Data2                 Merged_Data

# ID cnt        ID    cnt               ID cnt1 cnt2
# A  3          A     2                 A   3   2
# B  13         B     22       -->      B   13  22
# C  23         C     12                C   23  12
# D  37         D     32                D   37  32
# F  3          E     2                 F   3   NA



#1. Merge type: left_join
Left_join<- left_join(DF, DF2, by ='ID'); Left_join
Left_join1<- left_join(DF2, DF, by ='ID');Left_join1

#2. Merge type: right_join
Right_join<- right_join(DF, DF2, by ='ID'); Right_join
Right_join1<- right_join(DF2, DF, by ='ID'); Right_join1

#3. Merge type: inner_join
Inner_join<- inner_join(DF, DF2, by ='ID'); Inner_join

#4. Merge type: full_join
Full_join<- full_join(DF, DF2, by ='ID'); Full_join



### Common Bioinformatics example
Exp<-read_xlsx("Annotation.xlsx", sheet = 7, range= NULL, col_names = TRUE); head(Exp)
Annotation<-read_xlsx("Annotation.xlsx", sheet = 8, range= NULL, col_names = TRUE); head(Annotation)


#1. Merge type: left_join
Left_join_Bi<- left_join(Annotation, Exp, by ='ID')

#2. Merge type: right_join
Right_join_Bi<- right_join(Annotation, Exp, by ='ID')

#3. Merge type: inner_join
Inner_join_Bi<- inner_join(Annotation, Exp, by ='ID')

#4. Merge type: full_join
Full_join_Bi<- full_join(Annotation, Exp, by ='ID')


NCBI_blastn <- read_xlsx("../Annotation.xlsx", sheet = 3, range= NULL, col_names = TRUE)
Barley_Gff <- read_xlsx("../Annotation.xlsx", sheet = 4, range= NULL, col_names = TRUE)
BGff_NCBI<-unique(left_join(NCBI_blastn,Barley_Gff, by ='Trans')) 






###################### Data Treatment ########################
##  Missing values identification and treatment in R
#install.packages("missForest")
library(missForest)
rm(list=ls())         # To delete all variables of workspace


# 1. Loading/Reading of data 
data <- iris
summary(data)

#2 checking about missing data: NA
is.na(data);
any(is.na(data))
sum(is.na(data))

#3. In case if you got data with missing values
# introduce missing data by prodNA from missForest library
# Generate 10% missing values at Random 
iris.mis <- prodNA(iris, noNA = 0.1)
summary(iris.mis)
is.na(iris.mis);
any(is.na(iris.mis))
sum(is.na(iris.mis))

## TO get missing data information column and row wise
colSums(is.na(iris.mis)) 
#sapply(iris.mis, function(x) sum(is.na(x)))

## Row wise NA count
rowSums(is.na(iris.mis))





######### Missing value treatment for continuous values ######


# Tastk 1. by dataframe subsetting, to remove categorical variable
        head(iris.mis)
        ## Approach 1: sub-setting 
        iris.mis1 <- iris.mis[,1:4] ; head(iris.mis1)
        iris.test <- iris.mis[,-5] ; head(iris.test)

        # Approach 2. by column names
        iris.mis$Species <- NULL; iris.mis

        # 3. by select function
        iris.mis <- subset(iris.mis, select = -c(Species)); iris.mis

# Check summary and dim
summary(iris.mis)
dim(iris.mis)




# Task -2: Treatment: NA values 
#1. low amount missing data: drop the data with NA
    iris.clean <- na.omit(iris.mis); 
    summary(iris.clean)

#2. Replacment of NA to 0s
iris.mis1[is.na(iris.mis1)] <- 0; summary(iris.mis1); describe(iris.mis1)
dim(iris.mis1)

#3. Imputing with Mean/Median/Mode
# sapply does not create a data frame, so we can wrap the sapply() function within data.frame().
df_iris_impute_mean <- data.frame(
                                   sapply( iris.mis, 
                                   function(x) ifelse(is.na(x), mean(x, na.rm = TRUE),x) )
                                  )
head(df_iris_impute_mean,5)

df_iris_impute_median <- data.frame(
                                    sapply( iris.mis, 
                                    function(x) ifelse(is.na(x), median(x, na.rm = TRUE),x))
                                    )
head(df_iris_impute_median,5)

#4 Add species column again to imputed dataframe
df_iris_impute_mean$Species <-data$Species

#5 Prediction Model: create predictive model to substitute missing data
# regression, ANOVA, Logistic regression 

#6. KNN Imputation

# R- packages for the treatment of missing values
# MICE
# Amelia
# missForest
# Hmisc
# mi 


