## Data Visualization
## Purpose : To understand data and explore hidden pattern
#  Requirement: data :(variable, vector, matrix, Df,List)
#  Possibility 1: Create dataset 
#              2: Use built-in dataset
#              3: import dataset
# use plot function plot ()

################ 1. Create  Datasets ###########################

  plot(1)
  plot(1:10)
  ?plot

# how to create data points for emprical research
    v1<-1:10;v1  
    v2<-seq(2,30,3);v2

    plot(1:10,seq(2,30,3))
    plot(v1,v2)

## Data point type: line
    plot(v1,v2,type = "l")
    plot(v1,v2,type = "l",main="PhD Course work",xlab = "Student",ylab="Marks")
    rm(list=ls())

## Generation of hypothesis modelling testing and analysis
## Assumption: 1: All the students are equally good
##             2: Majority is good
##	           3: Majority is not good
##
## Function  : runif():data-points from a uniform distribution
##           : rnorm():data-points from a normal distribution.
## 	         : dlnorm(): lognormal  distribution for high-end tailed data

            set.seed(100) #  for uniform initialize of pseudorandom number generator.

            v1<-1:20; v1    # Generated data for student count 

## uniform distribution:
#syntax: runif(number,low, high,)/runif(number,min=0, max=1)
    v2<-runif(20,0,1);v2 	 # To generate class Attendence 
    plot(v1,v2,type = "l",main="R-Course",xlab = "Student",ylab="Performance",
     col="red")

## Normal distribution syntax: rnorm(number,mean, sd)
v3<-(rnorm(20,0,1));v3 # Normal distribution based data
plot(v1,v3,type = "l",main="R-Course",xlab = "Student",ylab="Performance/Marks",
     col="red")
lines(v1,v2, col="green",type = "l",lty=1,lwd=2)
abline(h=0.5, col="blue")
abline(v=10, col="red")

#v4<-(dlnorm(x, meanlog=0, sdlog=1), from=0, to=20); v4
#curve(dlnorm((x, meanlog=0, sdlog=1), from=0, to=18))


## log-normal distribution data point
x_dlnorm <- seq(0, 20, by = 1)  
v4 <- dlnorm(x_dlnorm) ; v4  
plot (v4, col="brown",type = "l")
plot(v1,v3,type = "l",main="R-Course",xlab = "Student",ylab="Performance/Marks",
     col="red")
lines(v1,v2, col="green",type = "l",lty=1,lwd=2)
lines(v1,v4, col="brown",type = "l",lty=1,lwd=2)
abline(h=0.5, col="blue")
abline(v=10, col="red")

### abline(a=NULL, b=NULL, h=NULL, v=NULL, ...)
# a,b : single values specifying the intercept and the slope of the line
# h : the y-value(s) for horizontal line(s)
# v : the x-value(s) for vertical line(s)
### Line type : lty=c(1,2),line type (lty) can be specified using either text 
# text ("blank","solid","dashed","dotted","dotdash","longdash","twodash")
# number (0, 1, 2, 3, 4, 5, 6). 
# Note that lty = "solid" is identical to lty=1.
### line width lwd()

legend(1,1,c("runif", "rnorm"), pch = c(1,1), lty = c(1,1),
       col = c("red","green"),cex = 0.5)

#####legend: Text of the legend
#Syntax: legend(x, y, legend, fill, col, bg, lty, cex, title, text.font, bg)
#Parameters:
# x and y: These are co-ordinates to be used to position the legend
#fill: Colors to use for filling the boxes with legend text
#col: Colors of lines
#bg: It defines background color for the legend box
#cex: Used for scaling
#title: Legend title        (optional)
#text.font: An integer specifying the font style of the legend (optional)
# cex is a number indicating the amount by which plotting text and 
#symbols should be scaled relative to the default. 1=default, 
#1.5 is 50% larger, 0.5 is 50% smaller, etc.

## 
rm(list=ls())
set.seed(100)
v1<-1:20; v1
v2<-runif(20,0,1);v2
v3<-abs(rnorm(20,0,1));v3

## To save the file with defined resolution
png(file="Plot.png", units="in", width=10, height=8, res=300)
plot(v1,v2,type = "b",main="R-Course",xlab = "Student",ylab="Marks",
     col="red")
lines(v1,v3, col="green",type = "b",lty=1,lwd=2)
abline(h=0.5, col="blue")
abline(v=10, col="blue")
dev.off()
getwd()

### T test
t.test(v2, v3)
t.test(v2, v4)

## Corelation 
cor(v2, v3)


