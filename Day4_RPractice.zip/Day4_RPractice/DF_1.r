#### 4. Dataframe ########## 
# Data frame is a list of vectors which are of equal length. 
# Accepts different data types (numeric, character, factor,...). 

## A. Data frame creation 
      # Syntax
      # data.frame(df, stringsAsFactors = TRUE)
      # Arguments:
      # df: collection of variables/vector/matrix as a data frame
      # stringsAsFactors: Convert string to factor by default

      # Create x, y, z, d variables
        x <- c(5,10,20,30)
        y <- c('candy', 'cola', 'cookies', 'water')
        z <- c(TRUE,FALSE,TRUE,FALSE)
        d <- c(2.5, 8.6, 10.5, 6.7)
  
      # Join the variables to create a data frame
        df <- data.frame(x,y,z,d)
        df

        typeof(d)           # determines the internal type or storage mode of an object i.e. integer, double
        class(df)     
         
      # To change name of data frame columns
        names(df) <- c('ID', 'items', 'availability', 'price')
        df  
  
        df; dim(df)
        
        
        # Note: to see comprehensive summary of dataframe 
        str(df)             #  function used to display the internal structure of any R object
        summary(df)
        
        
## B. Access of Dataframe 
       

        # 1. For single element: exact coordinates 
              # df[1,2] selects the element at the first row and second column.
              df[1,2]
  
        # 2. For multiple elements: Range
              # df [1:2,2:5] 
              df[1:2,2:3] 
  
        # 3. Whole columns 
              # df [,1] selects all elements of the first column.
              df [,1] 
  
        # 4. Whole rows
              # df [1,] selects all elements of the first row  
              df [1,] 
  
              
              
        ## slicing/subsetting of dataframe. 
        #select one or many elements from a matrix by using the square brackets [row, col]. 
              
              
        # 5. Slice with columns name
              df[, c('ID', 'items')]
  
        # 6. Adding a Column to Data Frame
              # use the symbol $ to append a new columns.
              # Existing dataframe i.e. df
              # Create a new vector
                quantity <- c(25, 45, 80, 15)
      
              # Add `quantity` to the `df` data frame
                df$quantity <- quantity
                df
              #Note: Number of elements of vector must be equal to the no of elements in data frame  
      
              ## Addition of Row and columns by rbind/cbind 
                dfrow<-c(1:5); dfrow
                df2 <- rbind(df,dfrow);df2
                dfcol<-c(1:6); dfcol
                df3 <- cbind(df,dfrow);df3
              
              ## Removal of column
                df4 <- df3[-c(1), -c(1)];df4
                df5 <- df3[-c(2), -c(1)];df5
                df6 <- df3[, -c(1:2)];df6
                
                ncol(df5)
                nrow(df5)
                length(df5)

        # 7. By subset() function.
              #Syntax: subset(x, condition)
                      #arguments:
                      # - x: data frame used to perform the subset
                      # - condition: define the conditional statement
                      subset(df, subset = price > 7)

        # 8. Merge
              authors <- data.frame(
              name = c("kapil", "sachin", "Rahul","Nikhil","Rohan"),
              nationality = c("US","Australia","US","UK","India"),
              retired = c("Yes","No","Yes","No","No"));authors
              
              books <-data.frame( 
                name = c("C", "C++","Java","php",".net","R"),
                title = c("Intro to C","Intro to C++", 
                          "Intro to java", "Intro to php", 
                          "Intro to .net", "Intro to R"),
                author = c("kapil", "kapil","sachin", "Rahul",
                           "Nikhil","Nikhil")); books
              merge(authors, books, by.x = "name",by.y = "author" )             

  ## C.  Deletion of variable
        rm(df); df
     
