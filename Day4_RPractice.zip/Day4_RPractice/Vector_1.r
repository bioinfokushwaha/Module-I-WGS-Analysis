##########  2. Vector  ########
# One-dimensional array.
# A vector can have all the basic data type such as
# logical, integer, double, complex, character and raw (mix of all) 
# The simplest way to build a vector in R, is to use the c command with ( ). 

## A. Vector creation Syntax
      # name_of_vector <- c(value1, value2,....n)
    
      # Single/ Multiple Elements Vector
      # Rules for vector naming: Same as variable
   
## B. Access of vector elements
      # Elements of a vector can be accessed using indexing [ ]
      # Indexing starts with position 1
      # name_of_variable
      
      Vec_num <- (15)
      Vec_num[1]
      Vec_num[2]
      Vec_num

      Vec_num <- c(15, 17, 19) # numeric vector
      Vec_num

      Vec_chr <- c("a", "b", "c") # Character vector
      Vec_chr

      Vec_logi <-  c(FALSE, FALSE, TRUE) # logical vector
      Vec_logi
      
      Vec_exp <- c('Mango','yellow',5,TRUE) # if one/more values are character, all DT will be characters 
      print(Vec_exp)

      #Note: class function
      class(Vec_num); class(Vec_chr); class(Vec_logi);  class(Vec_exp); 

      # Some methods for quick vector creation
        Vec_cr <- 1:10; print(Vec_cr)
        Vec_cr  <- 1.5:5.6; print(Vec_cr)
        
        # seq function
        #Vec_cr <- seq(start digit, end digit, "difference in numbers " by = 0.4)
        Vec_cr <- seq(5, 9, by = 0.4); print(Vec_cr)
      

## C.  Deletion of vector
        rm(Vec_num); Vec_num
        rm (Vec_cr,Vec_logi); Vec_chr; Vec_logi

    
    
## D.slicing/subsetting of vector. 
  
      # 1. by giving position of single element
          vec_slice <- c(1,2,3,4,5,6,7,8,9,10)
          vec_slice[2]

      # 2. By giving range of elements
          vec_slice[1:5]


## E. Vector manipulation ( Arithematic and Logical operations)
      # Two vectors of same length can be added, subtracted, multiplied or divided 
      # Operation perform element to elements of vectors 
      # Arithematic operations

      # + 	: Addition
      # - 	: Subtraction
      # * 	: Multiplication
      # / 	: Division
      # ^ or **  : Exponentiation 
      # %% 	: Modulus (Remainder from division)
      # %/% : Integer Division

        x<-c(1,3,5,7,9);x
        y<-c(2,4,6,8,10);y
        x+y; 
        x-y; 
        x*y; 
        y/x; 
        y%%x
        y%/%x
        x^2 ; 
        x^y;

      # Vector element recycling
          #shorter vector recycled to complete the operations.
          Vec_re1 <- c(2,6,17,5,10,12)
          Vec_re2 <- c(7,12)        # Vec_re2 behave like c(7,12,7,12,7,12)
        
          Addition <- Vec_re1 + Vec_re2
          print(Addition)     
        
          Subtraction <- Vec_re1 - Vec_re2
          print(Subtraction)

          
          # Logical operation 

              # < 	:less than
              # <= 	:less than or equal to
              # > 	:greater than
              # >= 	:greater than or equal to
              # == 	:exactly equal to
              # != 	:not equal to
              # x | y 	:x OR y
              # x & y 	:x AND y


                vec_logi <- c(1:10)
                vec_logi >5
                
            # Add multiple condition
                vec_logi >5 & vec_logi < 8
               
                
            # Logical statements wrapped inside the []. 
                # variable_name[(conditional_statement).....]
                
                #Example
                vec_logi[vec_logi>5]
                vec_logi[vec_logi >5 & vec_logi < 8]
                vec_logi[(vec_logi>5) & (vec_logi<7)]
  