#### 5. List ########## 
# Data object which are used for collection of objects and use them when we need them. 
# Accepts different data types (numeric, character, factor). 
# Accepts different data object (vector, matrix, dataframe). 


## A. Data frame creation 
    # Syntax
    #list(element_1, ...)
    # arguments:
    # -element_1: store any type of R object. each object needs to be separated by a comma
    rm(list=ls())
    Vector  <- 1:10; Vector
    Matrix  <- matrix(1:10, ncol = 10); Matrix; dim(Matrix)
    Df <- cars[1:10,]; Df

    List <- list(Vector, Matrix, Df)
    List


## B. Access of list items
    List
    dim(List)  #Note: dim function
    str(List)  #Note: str function
    
    # Need to use the [[index]] to select an element in a list. 
    # To extract dataframe from list
    List[[3]]
    
    
## C. Delete list
    
    rm(List)

    ## To delete all variables of workspace
    ls()
    rm(list=ls()) 
    ls ()
