## Case Study: "Strong Maternal Effects on Gene Expression in Arabidopsis lyrata Hybrids"
# (https://academic.oup.com/mbe/article/33/4/984/2579518?login=false)
# https://link.springer.com/article/10.1186/s12870-020-2305-x
#setwd("D:/NIAB/PhD_Teaching/R"); dir()

### Type 3: Import of external data in R

rm(list=ls())

dir()

#data<- read.csv ("Crossing_Trinity_count_normalized.csv", sep="\t",header=TRUE, stringsAsFactors = FALSE) 
data<- read.table("CrossingPolution_5K.txt", sep="\t",header=TRUE,na.strings = "NA") 
datap<-data[,2:38]

#### 1:Density Plot 
datalog<-datap
datalog[,1:37]<- log(datap[1:37],10)
plot(density(datalog$Desiree), main="Density plot of gene expression profiles", 
      col="red",ylim=c(0,0.5),xlim=c(-3,6), lwd = 2, xlab="Gene Expression")

cl <- rainbow(38) # Create a list of colors to use for the lines.

# Now fill plot with the log transformed coverage data from the
for(i in 2:37) {
  lines(density(datalog[,i]), col = cl[i])
}

lines(density(datalog$sw1015), col = "yellow",lwd = 3)
lines(density(datalog$Sapomira), col = "dark green",lwd = 3)
legend("topright", c("Mather:Desire","Father:SW1015","X:Sapomira"), cex=0.5,
      horiz=FALSE ,  lwd=c(2,2),  col=c("red","yellow","dark green"))


######## 2: Heatmap of sample-to-sample distances using the rlog-transformed values.####
#install.packages("pheatmap")
#install.packages("RColorBrewer")
library("pheatmap")
library("RColorBrewer")

data1<- datap
head(data1, 3)

data1t<-t(data1); head(data1t, 5)
dataps<-scale(data1t, center = TRUE, scale = apply(data1t, 2, sd, na.rm = TRUE)) 

# Distance
sampleDists <- dist(dataps); sampleDists 

# Distance Matrix
sampleDistMatrix <- as.matrix( sampleDists );sampleDistMatrix; rownames(sampleDistMatrix)
dim(sampleDistMatrix);dim(data1)
#rownames(sampleDistMatrix) <- colnames(data1)
#colnames(sampleDistMatrix) <- colnames(data1)
colors <- colorRampPalette( rev(brewer.pal(9, "Blues")) )(255)
dev.off()
pheatmap(sampleDistMatrix, clustering_distance_rows = sampleDists, clustering_distance_cols = sampleDists, 
         col = colors, clustering_method ="complete",cutree_rows = 5)


############# 3. PCA Plot ###
data1
#datap<-setNames(data.frame(t(data1[,-1])),data1[,1])
pcaResult<-prcomp(t(data1))
#attributes(pcaResult)
summary(pcaResult) 
## Set up plot  pcaResult$x
plot(pcaResult$x, pch=21,  bg=rainbow(38), main= 'Principal components of samples', 
     xlab= "PC1(75.15%)", ylab= "PC2(19.56%)")

## Plot labels
text(x= pcaResult$x[,1], y= pcaResult$x[,2], labels=rownames(pcaResult$x), cex= 0.8)


### 4. Comparison of Expression
plot(data1$Desiree, data1$sw1015, pch=20,col="grey")
plot(log(data1$Desiree,10), log(data1$sw1015,10), pch=20,col="grey")
abline(lm(Desiree~sw1015,data=datalog),col='red')
abline(0,1,col='red')


### Test: Chi-square test of independence tests 
#  relationship between two categorical variables. The null and alternative hypotheses are:
#  H0 : the variables are independent and no relationship between the two categorical variables. 
#       Knowing the value of one variable does not help to predict the value of the other variable

# H1 : variables are dependent, there is a relationship between the two categorical variables. 
#      Knowing the value of one variable helps to predict the value of the other variable

chisq.test(data1$Desiree, data1$sw1015,correct=FALSE )
t.test(data1$Desiree, data1$sw1015 )

?chisq.test

## Export 
library(rio)
export(as.matrix(data1), "PCA.txt")

